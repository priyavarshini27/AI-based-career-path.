import { Career } from "../types";

export const careers: Career[] = [
  {
    id: "software-developer",
    title: "Software Developer",
    description: "Design, develop, and maintain software applications and systems.",
    requiredEducation: ["Bachelor's Degree", "Master's Degree"],
    averageSalary: {
      amount: 105000,
      currency: "USD"
    },
    growthOutlook: "Strong",
    skills: ["Programming", "Problem Solving", "Critical Thinking", "Teamwork"]
  },
  {
    id: "data-scientist",
    title: "Data Scientist",
    description: "Analyze and interpret complex data to help guide organizational decision-making.",
    requiredEducation: ["Master's Degree", "Doctoral Degree"],
    averageSalary: {
      amount: 120000,
      currency: "USD"
    },
    growthOutlook: "Very Strong",
    skills: ["Programming", "Data Analysis", "Critical Thinking", "Research"]
  },
  {
    id: "ux-designer",
    title: "UX Designer",
    description: "Create meaningful and relevant experiences for users interacting with products.",
    requiredEducation: ["Bachelor's Degree"],
    averageSalary: {
      amount: 95000,
      currency: "USD"
    },
    growthOutlook: "Strong",
    skills: ["Graphic Design", "Research", "Creativity", "Communication"]
  },
  {
    id: "marketing-manager",
    title: "Marketing Manager",
    description: "Develop and implement marketing strategies to promote products or services.",
    requiredEducation: ["Bachelor's Degree", "Master's Degree"],
    averageSalary: {
      amount: 85000,
      currency: "USD"
    },
    growthOutlook: "Moderate",
    skills: ["Digital Marketing", "Communication", "Leadership", "Creativity"]
  },
  {
    id: "teacher",
    title: "Teacher",
    description: "Educate students in various subjects and prepare them for future academic success.",
    requiredEducation: ["Bachelor's Degree", "Master's Degree"],
    averageSalary: {
      amount: 60000,
      currency: "USD"
    },
    growthOutlook: "Stable",
    skills: ["Teaching", "Communication", "Patience", "Adaptability"]
  },
  {
    id: "healthcare-professional",
    title: "Healthcare Professional",
    description: "Provide medical care and services to patients in various settings.",
    requiredEducation: ["Bachelor's Degree", "Master's Degree", "Doctoral Degree"],
    averageSalary: {
      amount: 80000,
      currency: "USD"
    },
    growthOutlook: "Very Strong",
    skills: ["Problem Solving", "Communication", "Teamwork", "Adaptability"]
  }
];

export const educationPaths = [
  {
    id: "computer-science",
    title: "Computer Science Degree",
    description: "Study the theory and practice of computation and its applications.",
    duration: "4 years",
    prerequisites: ["High School Diploma", "Mathematics Proficiency"],
    outcomes: ["Software Developer", "Data Scientist", "IT Consultant"]
  },
  {
    id: "business-administration",
    title: "Business Administration Degree",
    description: "Learn principles and practices of business management and operations.",
    duration: "4 years",
    prerequisites: ["High School Diploma"],
    outcomes: ["Business Manager", "Marketing Manager", "Entrepreneur"]
  },
  {
    id: "nursing",
    title: "Nursing Degree",
    description: "Prepare for a career in healthcare with focus on patient care.",
    duration: "4 years",
    prerequisites: ["High School Diploma", "Biology Background"],
    outcomes: ["Registered Nurse", "Nurse Practitioner", "Healthcare Administrator"]
  },
  {
    id: "graphic-design",
    title: "Graphic Design Degree",
    description: "Develop skills in visual communication and digital media.",
    duration: "4 years",
    prerequisites: ["High School Diploma", "Art Portfolio"],
    outcomes: ["Graphic Designer", "UX Designer", "Art Director"]
  },
  {
    id: "education",
    title: "Education Degree",
    description: "Learn teaching methodologies and educational theories.",
    duration: "4 years",
    prerequisites: ["High School Diploma"],
    outcomes: ["Teacher", "Educational Consultant", "Curriculum Developer"]
  }
];