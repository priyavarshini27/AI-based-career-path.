export interface UserProfile {
  country: string;
  educationLevel: string;
  interests: string[];
  skills: string[];
  preferredWorkEnvironment?: string;
}

export interface EducationPath {
  id: string;
  title: string;
  description: string;
  duration: string;
  prerequisites: string[];
  outcomes: string[];
  institutions?: string[];
}

export interface Career {
  id: string;
  title: string;
  description: string;
  requiredEducation: string[];
  averageSalary: {
    amount: number;
    currency: string;
  };
  growthOutlook: string;
  skills: string[];
}

export interface JobRecommendation {
  id: string;
  title: string;
  company?: string;
  description: string;
  matchPercentage: number;
  requiredSkills: string[];
  location: string;
  isRemote: boolean;
}

export type RecommendationType = "education" | "career" | "job";

export interface Recommendation {
  type: RecommendationType;
  items: (EducationPath | Career | JobRecommendation)[];
}