import React from 'react';
import { GraduationCap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <GraduationCap className="h-8 w-8" />
          <h1 className="text-2xl font-bold tracking-tight">CareerPathAI</h1>
        </div>
        <nav className="hidden md:flex space-x-8">
          <a href="#" className="font-medium hover:text-blue-100 transition-colors">Home</a>
          <a href="#" className="font-medium hover:text-blue-100 transition-colors">About</a>
          <a href="#" className="font-medium hover:text-blue-100 transition-colors">Resources</a>
          <a href="#" className="font-medium hover:text-blue-100 transition-colors">Contact</a>
        </nav>
        <button className="md:hidden text-white focus:outline-none">
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </header>
  );
};

export default Header;