import React, { useState } from 'react';
import { Recommendation, Career, EducationPath, JobRecommendation } from '../types';
import { Briefcase, GraduationCap, Building } from 'lucide-react';

interface RecommendationResultsProps {
  recommendations: Recommendation[];
  onReset: () => void;
}

const RecommendationResults: React.FC<RecommendationResultsProps> = ({ 
  recommendations, 
  onReset 
}) => {
  const [activeTab, setActiveTab] = useState<'education' | 'career' | 'job'>('education');
  
  const getActiveRecommendation = () => {
    return recommendations.find(rec => rec.type === activeTab);
  };
  
  const getTabCount = (type: 'education' | 'career' | 'job') => {
    const rec = recommendations.find(r => r.type === type);
    return rec ? rec.items.length : 0;
  };
  
  const educationCount = getTabCount('education');
  const careerCount = getTabCount('career');
  const jobCount = getTabCount('job');
  
  if (recommendations.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-8 max-w-2xl mx-auto text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">No Recommendations Found</h2>
        <p className="text-gray-600 mb-6">
          We couldn't find any suitable recommendations based on your profile. 
          Try adjusting your interests and skills to get better results.
        </p>
        <button
          onClick={onReset}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          Start Over
        </button>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-lg max-w-4xl mx-auto">
      <div className="border-b border-gray-200">
        <nav className="flex" aria-label="Tabs">
          {educationCount > 0 && (
            <button
              onClick={() => setActiveTab('education')}
              className={`py-4 px-6 flex items-center text-sm font-medium border-b-2 ${
                activeTab === 'education'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <GraduationCap className="mr-2 h-5 w-5" />
              Education Paths
              <span className="ml-2 bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full">
                {educationCount}
              </span>
            </button>
          )}
          
          {careerCount > 0 && (
            <button
              onClick={() => setActiveTab('career')}
              className={`py-4 px-6 flex items-center text-sm font-medium border-b-2 ${
                activeTab === 'career'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Briefcase className="mr-2 h-5 w-5" />
              Career Options
              <span className="ml-2 bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full">
                {careerCount}
              </span>
            </button>
          )}
          
          {jobCount > 0 && (
            <button
              onClick={() => setActiveTab('job')}
              className={`py-4 px-6 flex items-center text-sm font-medium border-b-2 ${
                activeTab === 'job'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Building className="mr-2 h-5 w-5" />
              Job Opportunities
              <span className="ml-2 bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full">
                {jobCount}
              </span>
            </button>
          )}
        </nav>
      </div>
      
      <div className="p-6">
        {activeTab === 'education' && educationCount > 0 && (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <GraduationCap className="mr-2 h-6 w-6 text-blue-600" />
              Recommended Education Paths
            </h2>
            <p className="text-gray-600">
              Based on your profile, here are education paths that could help you achieve your career goals.
            </p>
            
            <div className="grid gap-6 mt-4">
              {getActiveRecommendation()?.items.map((item) => {
                const path = item as EducationPath;
                return (
                  <div key={path.id} className="border border-gray-200 rounded-lg p-6 transition-all duration-200 hover:shadow-md">
                    <h3 className="text-lg font-semibold text-gray-800">{path.title}</h3>
                    <p className="text-gray-600 mt-2">{path.description}</p>
                    
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-700">Duration</h4>
                        <p className="mt-1 text-sm text-gray-600">{path.duration}</p>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-700">Prerequisites</h4>
                        <ul className="mt-1 text-sm text-gray-600 list-disc list-inside">
                          {path.prerequisites.map((prereq, index) => (
                            <li key={index}>{prereq}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="text-sm font-medium text-gray-700">Potential Career Outcomes</h4>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {path.outcomes.map((outcome, index) => (
                          <span 
                            key={index}
                            className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                          >
                            {outcome}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        
        {activeTab === 'career' && careerCount > 0 && (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <Briefcase className="mr-2 h-6 w-6 text-blue-600" />
              Recommended Career Options
            </h2>
            <p className="text-gray-600">
              These career paths align with your interests, skills, and education level.
            </p>
            
            <div className="grid gap-6 mt-4">
              {getActiveRecommendation()?.items.map((item) => {
                const career = item as Career;
                return (
                  <div key={career.id} className="border border-gray-200 rounded-lg p-6 transition-all duration-200 hover:shadow-md">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-800">{career.title}</h3>
                        <p className="text-gray-600 mt-1">{career.description}</p>
                      </div>
                      <div className="bg-green-100 text-green-800 text-sm font-medium px-3 py-1 rounded-full">
                        {career.growthOutlook} Growth
                      </div>
                    </div>
                    
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-700">Required Education</h4>
                        <ul className="mt-1 text-sm text-gray-600 list-disc list-inside">
                          {career.requiredEducation.map((edu, index) => (
                            <li key={index}>{edu}</li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-700">Average Salary</h4>
                        <p className="mt-1 text-sm text-gray-600">
                          {career.averageSalary.amount.toLocaleString()} {career.averageSalary.currency} per year
                        </p>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="text-sm font-medium text-gray-700">Key Skills</h4>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {career.skills.map((skill, index) => (
                          <span 
                            key={index}
                            className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        
        {activeTab === 'job' && jobCount > 0 && (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <Building className="mr-2 h-6 w-6 text-blue-600" />
              Job Opportunities
            </h2>
            <p className="text-gray-600">
              Jobs you may be eligible for based on your education and skills.
            </p>
            
            <div className="grid gap-6 mt-4">
              {getActiveRecommendation()?.items.map((item) => {
                const job = item as JobRecommendation;
                return (
                  <div key={job.id} className="border border-gray-200 rounded-lg p-6 transition-all duration-200 hover:shadow-md">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-800">{job.title}</h3>
                        {job.company && <p className="text-gray-500">{job.company}</p>}
                      </div>
                      <div 
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          job.matchPercentage >= 90 
                            ? 'bg-green-100 text-green-800' 
                            : job.matchPercentage >= 75 
                              ? 'bg-blue-100 text-blue-800' 
                              : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {job.matchPercentage}% Match
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mt-2">{job.description}</p>
                    
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-700">Location</h4>
                        <p className="mt-1 text-sm text-gray-600 flex items-center">
                          {job.location}
                          {job.isRemote && (
                            <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                              Remote
                            </span>
                          )}
                        </p>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-700">Required Skills</h4>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {job.requiredSkills.map((skill, index) => (
                            <span 
                              key={index}
                              className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                        View Details
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        
        <div className="mt-8 pt-4 border-t border-gray-200 flex justify-between">
          <button
            onClick={onReset}
            className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
          >
            Start Over
          </button>
          
          <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
            Save Recommendations
          </button>
        </div>
      </div>
    </div>
  );
};

export default RecommendationResults;