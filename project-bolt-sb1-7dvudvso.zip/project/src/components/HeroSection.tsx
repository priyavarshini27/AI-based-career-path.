import React from 'react';
import { GraduationCap, Briefcase, Award } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <div className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-16 lg:py-24">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <div className="lg:w-1/2 mb-10 lg:mb-0">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight mb-4">
              Find Your Perfect Career Path with AI
            </h1>
            <p className="text-lg md:text-xl text-blue-100 mb-8 max-w-xl">
              Get personalized education and career recommendations based on your profile, interests, and skills.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center space-x-2 bg-white bg-opacity-20 px-4 py-2 rounded-lg backdrop-blur-sm">
                <GraduationCap className="h-5 w-5" />
                <span>Education Plans</span>
              </div>
              <div className="flex items-center space-x-2 bg-white bg-opacity-20 px-4 py-2 rounded-lg backdrop-blur-sm">
                <Briefcase className="h-5 w-5" />
                <span>Career Paths</span>
              </div>
              <div className="flex items-center space-x-2 bg-white bg-opacity-20 px-4 py-2 rounded-lg backdrop-blur-sm">
                <Award className="h-5 w-5" />
                <span>Job Eligibility</span>
              </div>
            </div>
          </div>
          
          <div className="lg:w-2/5">
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-white border-opacity-20">
              <h2 className="text-xl font-semibold mb-4">How It Works</h2>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="flex-shrink-0 bg-blue-500 rounded-full h-6 w-6 flex items-center justify-center mt-0.5">
                    <span className="text-sm font-bold">1</span>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium">Create Your Profile</h3>
                    <p className="text-sm text-blue-100">Enter your location, education, and interests</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 bg-blue-500 rounded-full h-6 w-6 flex items-center justify-center mt-0.5">
                    <span className="text-sm font-bold">2</span>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium">Get AI Recommendations</h3>
                    <p className="text-sm text-blue-100">Receive personalized education and career suggestions</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 bg-blue-500 rounded-full h-6 w-6 flex items-center justify-center mt-0.5">
                    <span className="text-sm font-bold">3</span>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium">Explore Opportunities</h3>
                    <p className="text-sm text-blue-100">Discover jobs and courses that match your profile</p>
                  </div>
                </li>
              </ul>
              <button className="w-full mt-6 py-3 bg-white text-blue-600 font-medium rounded-lg hover:bg-opacity-90 transition-colors">
                Get Started
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;