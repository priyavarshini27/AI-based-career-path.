export interface Country {
  code: string;
  name: string;
  educationSystem: string[];
}

export const countries: Country[] = [
  {
    code: "US",
    name: "United States",
    educationSystem: [
      "High School Diploma",
      "Associate's Degree",
      "Bachelor's Degree",
      "Master's Degree",
      "Doctoral Degree"
    ]
  },
  {
    code: "UK",
    name: "United Kingdom",
    educationSystem: [
      "GCSE",
      "A-Levels",
      "Foundation Degree",
      "Bachelor's Degree",
      "Master's Degree",
      "Doctoral Degree"
    ]
  },
  {
    code: "CA",
    name: "Canada",
    educationSystem: [
      "High School Diploma",
      "College Diploma",
      "Bachelor's Degree",
      "Master's Degree",
      "Doctoral Degree"
    ]
  },
  {
    code: "AU",
    name: "Australia",
    educationSystem: [
      "High School Certificate",
      "Vocational Education",
      "Bachelor's Degree",
      "Master's Degree",
      "Doctoral Degree"
    ]
  },
  {
    code: "IN",
    name: "India",
    educationSystem: [
      "Secondary School Certificate",
      "Higher Secondary Certificate",
      "Bachelor's Degree",
      "Master's Degree",
      "Doctoral Degree"
    ]
  },
  {
    code: "DE",
    name: "Germany",
    educationSystem: [
      "Hauptschulabschluss",
      "Realschulabschluss",
      "Abitur",
      "Bachelor's Degree",
      "Master's Degree",
      "Doctoral Degree"
    ]
  },
  {
    code: "JP",
    name: "Japan",
    educationSystem: [
      "High School Diploma",
      "Associate's Degree",
      "Bachelor's Degree",
      "Master's Degree",
      "Doctoral Degree"
    ]
  }
];

export const getEducationLevels = (countryCode: string): string[] => {
  const country = countries.find(c => c.code === countryCode);
  return country ? country.educationSystem : [];
};