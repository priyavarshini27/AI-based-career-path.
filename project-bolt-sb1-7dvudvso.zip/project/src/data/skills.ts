export const skills = [
  "Programming",
  "Data Analysis",
  "Digital Marketing",
  "Content Writing",
  "Graphic Design",
  "Project Management",
  "Teaching",
  "Customer Service",
  "Sales",
  "Accounting",
  "Problem Solving",
  "Critical Thinking",
  "Leadership",
  "Communication",
  "Teamwork",
  "Time Management",
  "Adaptability",
  "Creativity",
  "Research",
  "Public Speaking"
];

export const interests = [
  "Technology",
  "Science",
  "Engineering",
  "Mathematics",
  "Arts",
  "Design",
  "Healthcare",
  "Education",
  "Business",
  "Finance",
  "Law",
  "Media",
  "Environment",
  "Social Work",
  "Sports",
  "Travel",
  "Food",
  "Music",
  "Entertainment",
  "Politics"
];

export const workEnvironments = [
  "Office",
  "Remote",
  "Hybrid",
  "Outdoors",
  "Laboratory",
  "Studio",
  "Hospital",
  "School",
  "Field Work",
  "Multiple Locations"
];