import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { countries, getEducationLevels } from '../data/countries';
import { interests, skills, workEnvironments } from '../data/skills';

interface UserInputFormProps {
  onSubmit: (profile: UserProfile) => void;
}

const UserInputForm: React.FC<UserInputFormProps> = ({ onSubmit }) => {
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<UserProfile>({
    country: '',
    educationLevel: '',
    interests: [],
    skills: [],
    preferredWorkEnvironment: ''
  });
  
  const [educationLevels, setEducationLevels] = useState<string[]>([]);
  const [isFormValid, setIsFormValid] = useState(false);
  
  useEffect(() => {
    if (profile.country) {
      setEducationLevels(getEducationLevels(profile.country));
    }
  }, [profile.country]);
  
  useEffect(() => {
    // Validate current step
    switch(step) {
      case 1:
        setIsFormValid(Boolean(profile.country && profile.educationLevel));
        break;
      case 2:
        setIsFormValid(profile.interests.length > 0);
        break;
      case 3:
        setIsFormValid(profile.skills.length > 0);
        break;
      default:
        setIsFormValid(true);
    }
  }, [step, profile]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };
  
  const handleMultiSelectChange = (
    type: 'interests' | 'skills', 
    item: string, 
    isChecked: boolean
  ) => {
    if (isChecked) {
      setProfile({ 
        ...profile, 
        [type]: [...profile[type], item] 
      });
    } else {
      setProfile({
        ...profile,
        [type]: profile[type].filter(i => i !== item)
      });
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 4) {
      setStep(step + 1);
    } else {
      onSubmit(profile);
    }
  };
  
  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto transition-all duration-300">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          {[1, 2, 3, 4].map((s) => (
            <div 
              key={s} 
              className={`flex items-center justify-center w-8 h-8 rounded-full ${
                s === step 
                  ? 'bg-blue-600 text-white' 
                  : s < step 
                    ? 'bg-green-500 text-white' 
                    : 'bg-gray-200 text-gray-600'
              } transition-colors duration-300`}
            >
              {s < step ? (
                <svg className="w-4 h-4\" fill="none\" stroke="currentColor\" viewBox="0 0 24 24">
                  <path strokeLinecap="round\" strokeLinejoin="round\" strokeWidth="2\" d="M5 13l4 4L19 7" />
                </svg>
              ) : (
                s
              )}
            </div>
          ))}
        </div>
        <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
          <div 
            className="bg-blue-600 h-full transition-all duration-500 ease-out"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {step === 1 && (
          <div className="space-y-4 animate-fadeIn">
            <h2 className="text-xl font-semibold text-gray-800">Basic Information</h2>
            <p className="text-gray-600">Let's start with your location and current education.</p>
            
            <div>
              <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-1">
                Country
              </label>
              <select
                id="country"
                name="country"
                value={profile.country}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">Select your country</option>
                {countries.map((country) => (
                  <option key={country.code} value={country.code}>
                    {country.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="educationLevel" className="block text-sm font-medium text-gray-700 mb-1">
                Current Education Level
              </label>
              <select
                id="educationLevel"
                name="educationLevel"
                value={profile.educationLevel}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                disabled={!profile.country}
                required
              >
                <option value="">Select your education level</option>
                {educationLevels.map((level) => (
                  <option key={level} value={level}>
                    {level}
                  </option>
                ))}
              </select>
              {!profile.country && (
                <p className="text-sm text-gray-500 mt-1">Please select a country first</p>
              )}
            </div>
          </div>
        )}
        
        {step === 2 && (
          <div className="space-y-4 animate-fadeIn">
            <h2 className="text-xl font-semibold text-gray-800">Your Interests</h2>
            <p className="text-gray-600">Select areas that interest you professionally.</p>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {interests.map((interest) => (
                <div key={interest} className="flex items-start">
                  <input
                    id={`interest-${interest}`}
                    type="checkbox"
                    className="h-4 w-4 mt-1 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={profile.interests.includes(interest)}
                    onChange={(e) => handleMultiSelectChange('interests', interest, e.target.checked)}
                  />
                  <label htmlFor={`interest-${interest}`} className="ml-2 block text-sm text-gray-700">
                    {interest}
                  </label>
                </div>
              ))}
            </div>
            
            {profile.interests.length === 0 && (
              <p className="text-sm text-red-500">Please select at least one interest</p>
            )}
          </div>
        )}
        
        {step === 3 && (
          <div className="space-y-4 animate-fadeIn">
            <h2 className="text-xl font-semibold text-gray-800">Your Skills</h2>
            <p className="text-gray-600">Select skills you possess or are developing.</p>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {skills.map((skill) => (
                <div key={skill} className="flex items-start">
                  <input
                    id={`skill-${skill}`}
                    type="checkbox"
                    className="h-4 w-4 mt-1 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={profile.skills.includes(skill)}
                    onChange={(e) => handleMultiSelectChange('skills', skill, e.target.checked)}
                  />
                  <label htmlFor={`skill-${skill}`} className="ml-2 block text-sm text-gray-700">
                    {skill}
                  </label>
                </div>
              ))}
            </div>
            
            {profile.skills.length === 0 && (
              <p className="text-sm text-red-500">Please select at least one skill</p>
            )}
          </div>
        )}
        
        {step === 4 && (
          <div className="space-y-4 animate-fadeIn">
            <h2 className="text-xl font-semibold text-gray-800">Work Preferences</h2>
            <p className="text-gray-600">Tell us about your preferred work environment.</p>
            
            <div>
              <label htmlFor="preferredWorkEnvironment" className="block text-sm font-medium text-gray-700 mb-1">
                Preferred Work Environment
              </label>
              <select
                id="preferredWorkEnvironment"
                name="preferredWorkEnvironment"
                value={profile.preferredWorkEnvironment || ''}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Select preferred environment</option>
                {workEnvironments.map((env) => (
                  <option key={env} value={env}>
                    {env}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
              <h3 className="font-medium text-blue-800 mb-2">Summary of Your Profile</h3>
              <ul className="text-sm text-blue-700 space-y-1">
                <li><span className="font-medium">Country:</span> {countries.find(c => c.code === profile.country)?.name}</li>
                <li><span className="font-medium">Education:</span> {profile.educationLevel}</li>
                <li><span className="font-medium">Interests:</span> {profile.interests.join(', ')}</li>
                <li><span className="font-medium">Skills:</span> {profile.skills.join(', ')}</li>
                {profile.preferredWorkEnvironment && (
                  <li><span className="font-medium">Preferred Environment:</span> {profile.preferredWorkEnvironment}</li>
                )}
              </ul>
            </div>
          </div>
        )}
        
        <div className="flex justify-between pt-4">
          {step > 1 ? (
            <button
              type="button"
              onClick={handleBack}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Back
            </button>
          ) : (
            <div></div>
          )}
          
          <button
            type="submit"
            disabled={!isFormValid}
            className={`px-4 py-2 rounded-md shadow-sm text-sm font-medium text-white 
              ${isFormValid 
                ? 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500' 
                : 'bg-blue-400 cursor-not-allowed'
              }`}
          >
            {step < 4 ? 'Continue' : 'Get Recommendations'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default UserInputForm;