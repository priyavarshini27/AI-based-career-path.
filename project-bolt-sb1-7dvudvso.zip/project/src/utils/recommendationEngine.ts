import { UserProfile, Recommendation, Career, EducationPath } from "../types";
import { careers, educationPaths } from "../data/careers";
import { countries } from "../data/countries";

// Simulates AI-based recommendation logic
export const generateRecommendations = (profile: UserProfile): Recommendation[] => {
  const recommendations: Recommendation[] = [];
  
  // Education path recommendations
  const relevantEducationPaths = educationPaths.filter(path => {
    // Check if the user's interests align with potential outcomes
    const hasRelevantOutcome = path.outcomes.some(outcome => 
      careers.some(career => 
        career.title === outcome && 
        profile.interests.some(interest => 
          career.skills.includes(interest) || 
          interest.toLowerCase().includes(career.title.toLowerCase())
        )
      )
    );
    
    // Check if the user meets prerequisites
    const meetsPrerequisites = path.prerequisites.some(prereq => 
      profile.educationLevel.includes(prereq) || 
      profile.educationLevel === prereq
    );
    
    return hasRelevantOutcome && meetsPrerequisites;
  });
  
  if (relevantEducationPaths.length > 0) {
    recommendations.push({
      type: "education",
      items: relevantEducationPaths
    });
  }
  
  // Career recommendations
  const relevantCareers = careers.filter(career => {
    // Check if the user's education meets requirements
    const hasRequiredEducation = career.requiredEducation.some(edu => 
      profile.educationLevel.includes(edu) || profile.educationLevel === edu
    );
    
    // Check if the user's interests align with the career
    const hasRelevantInterests = profile.interests.some(interest => 
      career.skills.includes(interest) || 
      interest.toLowerCase().includes(career.title.toLowerCase())
    );
    
    // Check if the user has relevant skills
    const hasRelevantSkills = profile.skills.some(skill => 
      career.skills.includes(skill)
    );
    
    return (hasRequiredEducation || hasRelevantSkills) && hasRelevantInterests;
  });
  
  if (relevantCareers.length > 0) {
    recommendations.push({
      type: "career",
      items: relevantCareers
    });
  }
  
  // Job recommendations (simplified for demo)
  const jobRecommendations = relevantCareers.map(career => ({
    id: `job-${career.id}`,
    title: `${career.title} Position`,
    company: getRandomCompany(),
    description: `An opportunity to work as a ${career.title} in a ${profile.preferredWorkEnvironment || "professional"} environment.`,
    matchPercentage: Math.floor(Math.random() * 30) + 70, // 70-100% match
    requiredSkills: career.skills.slice(0, 3),
    location: profile.country,
    isRemote: profile.preferredWorkEnvironment === "Remote"
  }));
  
  if (jobRecommendations.length > 0) {
    recommendations.push({
      type: "job",
      items: jobRecommendations
    });
  }
  
  return recommendations;
};

// Helper function to get a random company name
const getRandomCompany = (): string => {
  const companies = [
    "TechNova Solutions",
    "Global Innovations Inc.",
    "Quantum Enterprises",
    "Apex Industries",
    "Horizon Healthcare",
    "Elemental Education Group",
    "Pinnacle Designs",
    "Catalyst Consulting"
  ];
  
  return companies[Math.floor(Math.random() * companies.length)];
};

export const getCountryEducationInfo = (countryCode: string): string => {
  const country = countries.find(c => c.code === countryCode);
  
  if (!country) return "Education system information not available.";
  
  const educationLevels = country.educationSystem.join(", ");
  
  return `${country.name}'s education system typically includes: ${educationLevels}.`;
};