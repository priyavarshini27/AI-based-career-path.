import React from 'react';
import { CheckCircle, Users, Globe, Book } from 'lucide-react';

const InfoSection: React.FC = () => {
  return (
    <div className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Why Choose CareerPathAI?</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our AI-powered platform provides personalized guidance to help you make informed decisions about your education and career.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md transition-transform hover:transform hover:scale-105">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Globe className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Country-Specific</h3>
            <p className="text-gray-600">
              Recommendations tailored to educational systems and job markets in your country.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md transition-transform hover:transform hover:scale-105">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <Book className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Educational Roadmaps</h3>
            <p className="text-gray-600">
              Clear pathways showing the education needed to reach your dream career.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md transition-transform hover:transform hover:scale-105">
            <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-4">
              <CheckCircle className="h-6 w-6 text-teal-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Job Eligibility</h3>
            <p className="text-gray-600">
              Discover which jobs you qualify for now and which will be available after further education.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md transition-transform hover:transform hover:scale-105">
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
              <Users className="h-6 w-6 text-red-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Personalized Plans</h3>
            <p className="text-gray-600">
              Recommendations based on your unique combination of skills, interests, and background.
            </p>
          </div>
        </div>
        
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl overflow-hidden shadow-xl">
          <div className="px-6 py-10 md:p-10 text-white">
            <div className="md:flex items-center justify-between">
              <div className="mb-6 md:mb-0">
                <h3 className="text-2xl font-bold mb-2">Ready to discover your career path?</h3>
                <p className="text-blue-100">
                  Get started today with your personalized AI-powered career recommendations.
                </p>
              </div>
              <div className="flex-shrink-0">
                <button className="px-6 py-3 bg-white text-blue-600 font-medium rounded-lg hover:bg-blue-50 transition-colors shadow-md">
                  Start Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfoSection;